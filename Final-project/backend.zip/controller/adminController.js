const User = require("../models/User");
const Job = require("../models/Job");


exports.getDashboardData = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalJobs = await Job.countDocuments();
   

    res.status(200).json({
      totalUsers,
      totalJobs,
      
    });
  } catch (error) {
    res.status(500).json({ message: "Admin dashboard failed", error: error.message });
  }
};