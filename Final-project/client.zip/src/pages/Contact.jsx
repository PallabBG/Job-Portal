import React from 'react'

const Contact = () => {
  return (
    <div className='max-w-6xl mx-auto px-4 py-10'>
      <div className='bg-white rounded-lg shadow p-6'>
        <h2 className='text-3xl font-bold mb-4 text-blue-600'>Contact</h2>
        <p>Email: pallabbanerjee074@gmail.com</p>
        <p>Phone: +91 7980984961</p>
      </div>
    </div>
  )
}

export default Contact