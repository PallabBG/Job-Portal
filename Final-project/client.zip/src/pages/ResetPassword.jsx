import React,{useState} from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const ResetPassword = () => {
  const navigate = useNavigate();
  const [form,setForm] = useState({email:""});

  const hc = (e)=> setForm({...form,[e.target.name]:e.target.value});
  const hs = async(e)=>{
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5500/api/auth/reset-password",form);
      alert(res.data.message);
      navigate("/reset-pass-otp",{state:{email:form.email}});
    } catch(err){
      console.error(err);
    }
  }
  return <>
  <div className='mt-10 w-full max-w-md mx-auto p-8 bg-white rounded-2xl shadow-md hover:shadow-2xl transition duration-300 overflow-hidden border group'>
    <form
        onSubmit={hs}
        className="bg-white p-8 rounded-2xl shadow-card space-y-4"
        >
        <h2>Reset Password</h2>
        <input
            type="email"
            name='email'
            placeholder='enter email'
            onChange={hc}
            value={form.email}
            className="w-full border p-3 rounded-lg"
            required
        />

        <button 
        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition"
        >
            Send Otp
        </button>
        </form>
    </div>
  </>
}

export default ResetPassword